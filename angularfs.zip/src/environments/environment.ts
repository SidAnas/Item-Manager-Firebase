// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBGGT3F21oJgwlwYbnMYeku0Zc-i8x7mIQ",
    authDomain: "fs1prod-24948.firebaseapp.com",
    databaseURL: "https://fs1prod-24948.firebaseio.com",
    projectId: "fs1prod-24948",
    storageBucket: "fs1prod-24948.appspot.com",
    messagingSenderId: "188570141450",
    // appId: "1:188570141450:web:3efba0371ecdc63a6f30f3",
    // measurementId: "G-9FMXJJH152"
  }


};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
